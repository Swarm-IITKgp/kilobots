licensed under creative commons attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0)
more info at http://creativecommons.org/licenses/by-nc-sa/3.0/

kilobot webpage is http://www.eecs.harvard.edu/ssr/projects/progSA/kilobot.html